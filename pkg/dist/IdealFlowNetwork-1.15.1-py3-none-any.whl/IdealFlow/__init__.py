from .Network import IFN
from .Classfier import Classifier
from .Command import CommandLine
from .Table import Table_Classifier
from .Text import NLP
