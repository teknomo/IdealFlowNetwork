from .network import IFN
from .classifier import Classifier