from .Network import IFN
