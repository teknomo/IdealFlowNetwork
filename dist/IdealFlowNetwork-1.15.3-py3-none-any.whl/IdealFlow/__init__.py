from .Network import IFN

